
using System;

namespace Wup.Jce
{
    public class JceDecodeException : Exception
    {
        public JceDecodeException(string str)
            : base(str)
        {
        }

    }
}