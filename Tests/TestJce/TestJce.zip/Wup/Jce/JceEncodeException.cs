using System;

namespace Wup.Jce
{

public class JceEncodeException: Exception
{

	public JceEncodeException(string str):base(str) 
    {
	}

}
}